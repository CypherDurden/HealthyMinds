# Sistema Healthy Minds

O Healthy Minds é um sistema de apoio emocional.

a)	O Sistema deve permitir que o usuário grave textos, sem ter retorno algum de IA (tab Diário)


# 1. Diagrama de casos de uso

```plantuml
@startuml
left to right direction
actor Usuário
rectangle "Sistema Healthy Minds" {
   Usuário -- (Escrever no Diário)
   Usuário -- (Consulta ao Advisor)
   Usuário -- (Visualizar Históricos de Diário e Consulta)
   Usuário -- (Excluir Registro dos Históricos de Diário e Consulta)
}
@enduml
```

## 2. Descrições dos casos de uso

### 2.1 Escrever no Diário (CDU001)
**Resumo:** o usuário deseja escrever algo sem obter uma resposta da IA. Para executar esta operação ele deverá preencher os campos Título e Conteúdo da tab Diário
**Ator Principal:** Usuário

**Pré Condições:** Nenhuma.

**Pós Condições:** Registro criado disponível no histórico.

#### 2.1.1 Fluxo Principal
1. O usuário preenche o campo **Título**
2. O usuário preenche o campo **Conteúdo**
3. O Usuário aperta o botão **Salvar Diário**


#### 2.1.2 Fluxos De Exceção

##### Passo 1a Usuário clica em "Salvar Diário" com todos os campos vazios.
1. Campos **Conteúdo** e **Título** vazios
2. O Usuário aperta o botão **Salvar Diário**

##### Passo 1b Usuário clica em "Salvar Diário" sem preencher o campo Título
1. O usuário preenche o campo **Conteúdo**
2. O Usuário aperta o botão **Salvar Diário**

##### Usuário clica em "Salvar Diário" sem preencher os campo Conteúdo
1. O usuário preenche o campo **Título**
2. O Usuário aperta o botão **Salvar Diário**


### 2.2 Consulta ao Advisor (CDU002)

**Resumo:** o usuário deseja escrever algo sem obter  obter resposta da IA. Para executar esta operação ele deverá preencher os campos Estado Mental, Quero dicas sobre, Digite mais sobre como você se sente e Tom da Consulta.

**Ator Principal:** Usuário

**Pré Condições:** Nenhuma.

**Pós Condições:** Registro criado disponível no histórico.

#### 2.2.1 Fluxo Principal
1. O usuário seleciona uma opção no dropdown **Estado Mental**
2. O usuário preenche o campo **Quero dicas sobre:**
3. O usuário preenche o campo **Diga mais sobre como você se sente:** 
4. O usuário seleciona uma opção no dropdown **Tom da Consulta**
5. O Usuário aperta o botão **Enviar para IA**


#### 2.2.2 Fluxos De Exceção

##### Passo 2a Usuário clica em "Enviar para IA" sem preencher/selecionar campo algum
1. Todos os campos vazios ou sem seleção
2. O Usuário aperta o botão "Enviar para IA"

##### Passo 2b Usuário clica em "Enviar para IA" sem selecionar Estado Mental
1. O usuário preenche/seleciona todos os campos exceto  **Estado Mental**
2. O Usuário aperta o botão **"Enviar para IA"**

##### Passo 2b Usuário clica em "Enviar para IA" sem preencher "Quero Dicas Sobre"
1. O usuário preenche/seleciona todos os campos exceto  **Quero Dicas Sobre**
2. O Usuário aperta o botão **"Enviar para IA"**


##### Passo 2c Usuário clica em "Enviar para IA" sem preencher "Diga mais sobre como você se sente:"
1. O usuário preenche/seleciona todos os campos exceto  **Quero Dicas Sobre**
2. O Usuário aperta o botão **"Enviar para IA"**

##### Passo 2d Usuário clica em "Enviar para IA" sem selecionar Tom da Consulta
1. O usuário preenche/seleciona todos os campos exceto  **Estado Mental**
2. O Usuário aperta o botão **"Enviar para IA"**



### 2.3 Visualizar Históricos de Diário(CDU003)
**Resumo:** o usuário deseja ver as listas com os registros do Diário ou da Consulta.

**Ator Principal:** Usuário.

**Pré Condições:** Entradas prévias de Diário registradas no banco de dados da aplicação.

**Prós Condições:** Listas de Diários e Consultas atualizadas.

#### 2.3.1 Fluxo Principal
1. O usuário seleciona aperta o botão "Atualizar Histórico" da tab Histórico.

### Fluxo De Exceção
N/A


### 2.4 Visualizar registro em Históricos (Diário e Consulta) (CDU005)
**Resumo:** o usuário deseja ver os detalhes de um registros do Diário ou da Consulta.

**Ator Principal:** Usuário.

**Pré Condições:** Entradas prévias de Diário e Consluta registradas no banco de dados da aplicação.

**Prós Condições:** Pop-up com deftalhes do registro consultado.

#### 2.4.1 Fluxo Principal
1. O usuário seleciona com dois cliques clique o registro que deseja ver.

### Fluxo De Exceção
N/A


### 2.5 Exclusão de Registro dos Históricos (Diário e Consulta) (CDU005)
**Resumo:** o usuário deseja excluir um registro das listas do Diário ou da Consulta.

**Ator Principal:** Usuário

**Pré Condições:** Entradas prévias de Diário/Consulta registradas no banco de dados da aplicação.

**Prós Condições:** Registro excluído não poderá estar mais disponível no banco de dados da aplicação.

### Fluxo Principal
1. O usuário seleciona com um clique o registro que deseja excluir;
2. Com o registro selecionado, o cliente clica em Excluir. 

### Fluxo De Exceção
N/A
