# Sistema Healthy Minds

O Healthy Minds é um sistema de apoio emocional.

a)	O Sistema deve permitir que o usuário grave textos, sem ter retorno algum de IA (tab Diário)


# 1. Diagrama de casos de uso

```plantuml
@startuml
left to right direction
actor Usuário
rectangle "Sistema Healthy Minds" {
   Usuário -- (Escrever no Diário)
   Usuário -- (Consulta ao Advisor)
   Usuário -- (Visualizar Históricos de Diário e Consulta)
   Usuário -- (Excluir Registro dos Históricos de Diário e Consulta)
}
@enduml
```

## 2. Descrições dos casos de uso

### 2.1 Escrever no Diário (CDU001)
**Resumo:** o usuário deseja escrever algo sem obter uma resposta da IA. Para executar esta operação ele deverá preencher os campos Título e Conteúdo da tab Diário
**Ator Principal:** Usuário

**Pré Condições:** Nenhuma.

**Pós Condições:** Registro criado disponível no histórico.

#### 2.1.1 Fluxo Principal
1. O usuário preenche o campo **Título**
2. O usuário preenche o campo **Conteúdo**
3. O Usuário aperta o botão **Salvar Diário**


#### 2.1.2 Fluxos De Exceção

##### Passo 1a Usuário clica em "Salvar Diário" com todos os campos vazios.
1. Campos **Conteúdo** e **Título** vazios
2. O Usuário aperta o botão **Salvar Diário**

##### Passo 1b Usuário clica em "Salvar Diário" sem preencher o campo Título
1. O usuário preenche o campo **Conteúdo**
2. O Usuário aperta o botão **Salvar Diário**

##### Usuário clica em "Salvar Diário" sem preencher os campo Conteúdo
1. O usuário preenche o campo **Título**
2. O Usuário aperta o botão **Salvar Diário**


### 2.2 Consulta ao Advisor (CDU002)

em desenvolvimento


### 2.3 Visualizar Históricos de Diário(CDU003)
em desenvolvimento

### 2.4 Visualizar registro em Históricos (Diário e Consulta) (CDU005)
em desenvolvimento

### 2.5 Exclusão de Registro dos Históricos (Diário e Consulta) (CDU005)
em desenvolvimento